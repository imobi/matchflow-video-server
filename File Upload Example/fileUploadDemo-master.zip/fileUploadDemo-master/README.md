# fileUploadDemo
This example demonstrates the use of the CollectionFS library:
https://github.com/CollectionFS/Meteor-CollectionFS
and will allow one to browse for files to upload, and then display the uploaded files on the screen, providing both a delete function and also a function to view/download the uploaded file. Please provide feedback, there are probably cleaner ways to do this, especially with the action to start the upload... the "change" event seems less than ideal.

For another way to do the same thing, see my other demo: https://github.com/wesyah234/fileUploadDemo2 which uses https://github.com/tomitrescak/meteor-uploads
